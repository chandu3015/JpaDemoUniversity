package com.chandu.jpaDemo.model;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Student extends User{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="stu_seq")
	@SequenceGenerator(name="stu_seq")
	private int studentId;
	
	private String name;
	
	@OneToOne(cascade = CascadeType.ALL, mappedBy="student")
	private Application application;
	
	
	public Student()
	{
		
	}

	public Student(String name, Application application) {
		super();
		this.name = name;
		this.application = application;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}
	
	
	
	
	
	

}
