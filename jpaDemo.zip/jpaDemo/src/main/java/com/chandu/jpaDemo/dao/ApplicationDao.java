package com.chandu.jpaDemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.chandu.jpaDemo.model.Application;




public interface ApplicationDao  extends JpaRepository<Application,Integer> {

	
	
}
