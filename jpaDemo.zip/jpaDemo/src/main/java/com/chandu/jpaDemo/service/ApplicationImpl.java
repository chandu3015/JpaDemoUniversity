package com.chandu.jpaDemo.service;

import org.springframework.stereotype.Service;

import com.chandu.jpaDemo.dao.ApplicationDao;
import com.chandu.jpaDemo.model.Application;

@Service
public class ApplicationImpl implements  ApplicationService {

	 private ApplicationDao applicationDao;
	 
	 public ApplicationImpl(ApplicationDao applicationDao)
	 {
		 this.applicationDao = applicationDao;
	 }
	 
	 
	 
	



	@Override
	public void submitApplication(Application application) {
		System.out.println(applicationDao.save(application));
		
	}

}
