package com.chandu.jpaDemo.service;

import com.chandu.jpaDemo.model.Staff;

public interface StaffService {

	int submitApplication(Staff staff);

}
