package com.chandu.jpaDemo.service;

import org.springframework.stereotype.Service;

import com.chandu.jpaDemo.dao.StaffDao;
import com.chandu.jpaDemo.model.Staff;

@Service
public class StaffImpl implements StaffService {

	private StaffDao staffDao;
	
	public StaffImpl(StaffDao staffDao)
	{
		this.staffDao = staffDao;
	}
	
	@Override
	public int submitApplication(Staff staff) {
		// TODO Auto-generated method stub
		return staffDao.save(staff).getStaffid();
	}

}
