package com.chandu.jpaDemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chandu.jpaDemo.model.Application;
import com.chandu.jpaDemo.model.Staff;
import com.chandu.jpaDemo.model.Student;
import com.chandu.jpaDemo.service.ApplicationService;
import com.chandu.jpaDemo.service.StaffService;
import com.chandu.jpaDemo.service.StudentService;


@Controller
public class UniversityController {
	
	private ApplicationService applicationService;
	
	private StudentService studentService;
	
	private StaffService staffService;
	
	public UniversityController(ApplicationService applicationService, StudentService studentService,StaffService staffService)
	{
		this.applicationService = applicationService;
		this.studentService = studentService;
		this.staffService = staffService;
	}
	
	@RequestMapping(value="/welcome", method = RequestMethod.GET)
	public String hello()
	{
		return "home";
	}
	
	@RequestMapping(value="/application", method = RequestMethod.GET)
	public String requestApplicationForm()
	{
		return "application";
	}
	
	@RequestMapping(value="/submitApplication", method = RequestMethod.POST)
	public String submitApplicationForm(ModelMap model, @RequestParam int greScore )
	{
		Application application = new Application();
		application.setGreScore(greScore);
		

		model.put("id", greScore);
		
		applicationService.submitApplication(application);
		return "formSubmit";
	}
	
	@RequestMapping(value="/student", method = RequestMethod.GET)
	public String requestStudentForm()
	{
		return "student";
	}
	
	@RequestMapping(value="/submitStudentApplication", method = RequestMethod.POST)
	public String submitStudentnForm(ModelMap model, @RequestParam String name, @RequestParam String uname, @RequestParam String password)
	{
		Student student = new Student();
		
		student.setName(name);
		student.setPassword(password);
		student.setUname(uname);
		
		int id = studentService.submitApplication(student);
		model.put("id", id);
		return "formSubmit";
	}
	
	
	@RequestMapping(value="/staff", method = RequestMethod.GET)
	public String requestStaffForm()
	{
		return "staff";
	}
	
	@RequestMapping(value="/submitStaffApplication", method = RequestMethod.POST)
	public String submitStaffForm(ModelMap model, @RequestParam String name, @RequestParam String uname, @RequestParam String password, @RequestParam String desg)
	{
		Staff staff = new Staff();
		
		staff.setName(name);
		staff.setPassword(password);
		staff.setUname(uname);
		staff.setDesg(desg);
		
		
		int id = staffService.submitApplication(staff);
		model.put("id", id);
		return "formSubmit";
	}
	
	

}
