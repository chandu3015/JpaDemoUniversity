package com.chandu.jpaDemo.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Staff extends User {

	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="staff_seq")
	@SequenceGenerator(name="staff_seq")
	private int staffid;
	
	private String name;
	
	private String desg;
	
	
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy="staff")
	private List<Application> applications;
	
	public Staff()
	{
		
	}
	

	public Staff( String name, String desg, List<Application> applications) {
		super();
		
		this.name = name;
		this.desg = desg;
		this.applications = applications;
	}

	public int getStaffid() {
		return staffid;
	}

	public void setStaffid(int staffid) {
		this.staffid = staffid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesg() {
		return desg;
	}

	public void setDesg(String desg) {
		this.desg = desg;
	}

	public List<Application> getApplications() {
		return applications;
	}

	public void setApplications(List<Application> applications) {
		this.applications = applications;
	}
	
	
}
