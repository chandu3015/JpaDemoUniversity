package com.chandu.jpaDemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.chandu.jpaDemo.model.Application;
import com.chandu.jpaDemo.model.Student;

public interface StudentDao extends JpaRepository<Student,Integer> {

}
