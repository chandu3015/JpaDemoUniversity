package com.chandu.jpaDemo.service;

import com.chandu.jpaDemo.model.Application;

public interface ApplicationService {
	
	public void submitApplication(Application application);

}
