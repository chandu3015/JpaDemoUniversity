package com.chandu.jpaDemo.service;

import com.chandu.jpaDemo.model.Student;

public interface StudentService {

	int submitApplication(Student student);

}
