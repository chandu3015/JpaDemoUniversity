package com.chandu.jpaDemo.service;

import org.springframework.stereotype.Service;

import com.chandu.jpaDemo.dao.StudentDao;
import com.chandu.jpaDemo.model.Student;

@Service
public class StudentImpl  implements StudentService {

	private StudentDao studentDao ;
	
	public StudentImpl(StudentDao studentDao )
	{
		this.studentDao = studentDao;
	}
	
	
	@Override
	public int submitApplication(Student student) {
		
		return studentDao.save(student).getStudentId();
	}

}
