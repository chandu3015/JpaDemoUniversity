package com.chandu.jpaDemo.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Application {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="app_seq")
	@SequenceGenerator(name="app_seq")
	private int applicationId;

	private int greScore;
	
	private int scoreByStaff;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Staff staff;//who evaluates the application
	
	@OneToOne(cascade = CascadeType.ALL)
	private Student student;//applicant
	
	
	public Application() {
		
	}
	

	public Application( int greScore, int scoreByStaff, Staff staff, Student student) {
		super();
		
		this.greScore = greScore;
		this.scoreByStaff = scoreByStaff;
		this.staff = staff;
		this.student = student;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public int getGreScore() {
		return greScore;
	}

	public void setGreScore(int greScore) {
		this.greScore = greScore;
	}

	public int getScoreByStaff() {
		return scoreByStaff;
	}

	public void setScoreByStaff(int scoreByStaff) {
		this.scoreByStaff = scoreByStaff;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
	
	
	
	
	
}
